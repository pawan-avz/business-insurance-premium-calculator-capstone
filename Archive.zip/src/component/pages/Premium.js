import React from 'react'
import '../css/home.css'
const Premium = () =>{
    return(
        <>
            <div className="home">
                <h1>Welcom to Premium page</h1>
            </div>


        
        </>
    )
}

 export default Premium;