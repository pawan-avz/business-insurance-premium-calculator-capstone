import React from 'react'
import '../css/home.css'
const Policies = () =>{
    return(
        <>
            <div className="home">
                <h1>Welcom to Policies page</h1>
            </div>


        
        </>
    )
}

 export default Policies;