import React from "react";
import { NavLink } from "react-router-dom";
import "../../css/form1.css";
const Form5 = () => {
  return (
    <>
      <h2
        style={{
          textAlign: "center",
          padding: "10px",
          fontSize: "30px",
          color: "#ccc",
          marginTop: "10px",
          boxShadow: "1px 1px 1px #ccc",
          textTransform: "uppercase",
        }}
      >
        Premium Calculated
      </h2>
      <div className="form5">
        <p>Coming soon</p>
      </div>
    </>
  );
};

export default Form5;
